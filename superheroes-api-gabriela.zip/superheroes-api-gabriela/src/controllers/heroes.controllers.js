const Hero = require("../models/Hero.js")

async function list(req, res){
    const movies = await Hero.findAll()
    return res.status(200).json(movies);
}

async function create(req, res){
    const {name, universe, power} = req.body;

    if (!name || !universe || !power) {
        return res.status(400).json({
            message: "Nome, universo e poder são obrigatórios"});
    }

    const hero = await Hero.create({name, universe, power});
    return res.status(201).json(hero);
}

async function update(req, res) {
    const {id} = req.params;
    const {name, universe, power} = req.body;

    const hero = await Hero.findByPk(id);

    if (!hero) {
        return res.status(404).json({message: "Herói não encontrado"});
    }

    if (!name || !universe || !power) {
        return res.status(400).json({message: "Nome, universo e poder são obrigatórios"});
    }

    await hero.update({name, universe, power});
    return res.status(200).json(hero);
}

async function partiaUpdate(req, res) {
    const {id} = req.params;
    const {name, universe, power} = req.body;

    const hero = await Hero.findByPk(id);

    if (!hero) {
        return res.status(404).json({message: "Herói não encontrado"});
    }

    const changes = {};
    if (name) changes.name = name;
    if (universe) changes.universe = universe;
    if (power) changes.power = power;

    if (Object.keys(changes).length === 0) {
        return res.status(400).json({message: "Envie ao menos um campo: name, universe ou power"});
    }

    await hero.update(changes);
    return res.status(200).json(hero);
}

async function remove(req, res) {
    const {id} = req.params;

    const hero = await Hero.findByPk(id);

    if (!hero) {
        return res.status(404).json({message: "Herói não encontrado"});
    }

    await hero.destroy();
    return res.status(204).send();
}

module.exports = {
    list,
    create,
    update,
    partiaUpdate,
    remove
};