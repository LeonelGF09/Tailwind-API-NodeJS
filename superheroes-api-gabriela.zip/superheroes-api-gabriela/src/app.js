const express = require("express");
const path = require("path");
const sequelize = require("./database/database.js");

const Hero = require("./models/Hero");
const Movie = require("./models/Movie");
const heroesRoutes = require("./routes/heroes.router.js");

const app = express();
app.use(express.static(path.join(__dirname, "..", "public")));
app.use(express.json());

Hero.belongsToMany( Movie, {
    through: "HeroMovies"
});

Movie.belongsToMany( Hero, {
    through: "MoviesHero"
});

app.use("/heroes", heroesRoutes);

sequelize
    .sync()
    .then(() => {
        console.log("Banco de Dados sincronizado.")
    })
    .catch((error) => {
        console.error("Erro a sincronizar o Banco", error)
    })

module.exports = app;